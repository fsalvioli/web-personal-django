from django.db import models

# Create your models here.
# Cada modelo representa una tabla en la base de datos. Cada registro de la Clase representa un campo de la tabla
class Project(models.Model): 
